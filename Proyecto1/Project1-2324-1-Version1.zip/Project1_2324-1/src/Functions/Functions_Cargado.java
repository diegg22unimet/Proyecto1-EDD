/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Functions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Functions_Cargado {
    
    public String txt_IsEmpty() throws IOException {
        String txt = "";
        String path = "test\\Proyecto1_2324.txt";

        File file = new File(path);
        if (!file.exists()) {
            file.createNewFile();
            return null;
        } else {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            //Leer linea por linea y meter lo leido en la variable txt
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.isEmpty()) {
                    txt += line + "\n";
                }
            }
            br.close();
            //Retornar null si no hay nada en el txt
            if (!"".equals(txt)) {
                return null;
            } else {
                return txt;
            }
        }
        
    }
 
}
