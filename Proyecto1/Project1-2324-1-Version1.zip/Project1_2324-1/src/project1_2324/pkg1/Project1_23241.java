/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project1_2324.pkg1;

import Interfaz.Bienvenida;


public class Project1_23241 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bienvenida ventana = new Bienvenida();
        ventana.setVisible(true);
    }
    
}
